package ciphergui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class CipherGUI extends JFrame {
    private PlayfairCipher playfairCipher;
    private JTextField playfairKeyInput;
    private JTextArea playfairInput, playfairOutput;
    private JButton playfairEncryptButton, playfairDecryptButton;

    private JTextField txtA, txtB;
    private JTextArea affineInput, affineOutput;
    private JButton affineEncryptButton, affineDecryptButton;
    private JTextArea tipsArea; 

    public CipherGUI() {
        super("Cipher Algorithms GUI");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception e) {
            e.printStackTrace();
        }

        tipsArea = new JTextArea("Select a cipher from the tabs above to see useful tips about each algorithm.");
        tipsArea.setEditable(false);
        tipsArea.setLineWrap(true);
        tipsArea.setWrapStyleWord(true);
        tipsArea.setFont(new Font("Arial", Font.PLAIN, 14));
        tipsArea.setBackground(new Color(240, 240, 240));

        playfairCipher = new PlayfairCipher("MONARCHY");
        JPanel playfairPanel = new JPanel(new BorderLayout(15, 15));
        playfairKeyInput = new JTextField("MONARCHY", 10);
        playfairInput = new JTextArea(10, 25);
        playfairOutput = new JTextArea(10, 25);
        playfairOutput.setEditable(false);
        playfairEncryptButton = new JButton("Encrypt", new ImageIcon("encrypt_icon.png"));
        playfairDecryptButton = new JButton("Decrypt", new ImageIcon("decrypt_icon.png"));

        playfairEncryptButton.addActionListener(e -> {
            playfairCipher = new PlayfairCipher(playfairKeyInput.getText());
            playfairOutput.setText(playfairCipher.encryptMessage(playfairInput.getText()));
        });

        playfairDecryptButton.addActionListener(e -> {
            playfairCipher = new PlayfairCipher(playfairKeyInput.getText());
            playfairOutput.setText(playfairCipher.decryptMessage(playfairInput.getText()));
        });

        JPanel playfairButtons = new JPanel();
        playfairButtons.add(playfairEncryptButton);
        playfairButtons.add(playfairDecryptButton);
        playfairPanel.add(playfairKeyInput, BorderLayout.NORTH);
        playfairPanel.add(new JScrollPane(playfairInput), BorderLayout.CENTER);
        playfairPanel.add(playfairButtons, BorderLayout.SOUTH);
        playfairPanel.add(new JScrollPane(playfairOutput), BorderLayout.EAST);

        JPanel affinePanel = new JPanel(new BorderLayout(15, 15));
        txtA = new JTextField(5);
        txtB = new JTextField(5);
        affineInput = new JTextArea(10, 25);
        affineOutput = new JTextArea(10, 25);
        affineOutput.setEditable(false);
        affineEncryptButton = new JButton("Encrypt", new ImageIcon("encrypt_icon.png"));
        affineDecryptButton = new JButton("Decrypt", new ImageIcon("decrypt_icon.png"));

        JPanel affineKeyPanel = new JPanel(new FlowLayout());
        affineKeyPanel.add(new JLabel("Key a:"));
        affineKeyPanel.add(txtA);
        affineKeyPanel.add(new JLabel("Key b:"));
        affineKeyPanel.add(txtB);

        affineEncryptButton.addActionListener(e -> {
            try {
                int a = Integer.parseInt(txtA.getText());
                int b = Integer.parseInt(txtB.getText());
                if (AffineCipher.gcd(a, 26) != 1) {
                    JOptionPane.showMessageDialog(null, "The value of a=" + a + " is not coprime with 26.");
                    return;
                }
                AffineCipher cipher = new AffineCipher(a, b);
                affineOutput.setText(cipher.encrypt(affineInput.getText()));
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Please enter valid integers for a and b.");
            }
        });

        affineDecryptButton.addActionListener(e -> {
            try {
                int a = Integer.parseInt(txtA.getText());
                int b = Integer.parseInt(txtB.getText());
                if (AffineCipher.gcd(a, 26) != 1) {
                    JOptionPane.showMessageDialog(null, "The value of a=" + a + " is not coprime with 26.");
                    return;
                }
                AffineCipher cipher = new AffineCipher(a, b);
                affineOutput.setText(cipher.decrypt(affineInput.getText()));
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Please enter valid integers for a and b.");
            }
        });

        JPanel affineButtons = new JPanel();
        affineButtons.add(affineEncryptButton);
        affineButtons.add(affineDecryptButton);
        affinePanel.add(affineKeyPanel, BorderLayout.NORTH);
        affinePanel.add(new JScrollPane(affineInput), BorderLayout.CENTER);
        affinePanel.add(affineButtons, BorderLayout.SOUTH);
        affinePanel.add(new JScrollPane(affineOutput), BorderLayout.EAST);

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Playfair Cipher", playfairPanel);
        tabbedPane.addTab("Affine Cipher", affinePanel);
        tabbedPane.addChangeListener(e -> {
            int selectedIndex = tabbedPane.getSelectedIndex();
            if (selectedIndex == 0) {
                tipsArea.setText("Playfair Cipher Tips:\n- Avoid duplicate letters in the key.\n- Replace 'J' with 'I'.\n- If a pair is the same, insert filler like 'X'.");
            } else {
                tipsArea.setText("Affine Cipher Tips:\n- Choose 'a' and 'b' such that gcd(a, 26) = 1.\n- The value of 'a' must be coprime with 26 for the cipher to work.");
            }
        });

        add(tabbedPane, BorderLayout.CENTER);
        add(new JScrollPane(tipsArea), BorderLayout.SOUTH);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(CipherGUI::new);
    }
}
