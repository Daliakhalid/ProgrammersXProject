package ciphergui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class IntroGUI extends JFrame {

    public IntroGUI() {
        super("Introduction to Ciphers");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(255, 255, 255, 120)); 
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); 

        JTextPane definitionPane = new JTextPane();
        definitionPane.setOpaque(false);
        definitionPane.setContentType("text/html");
        definitionPane.setText(getFormattedText());
        definitionPane.setEditable(false);
        definitionPane.setMargin(new Insets(10, 10, 10, 10));

        JButton startButton = new JButton("Start Learning!");
        styleButton(startButton);

        mainPanel.add(new JScrollPane(definitionPane), BorderLayout.CENTER);
        mainPanel.add(startButton, BorderLayout.SOUTH);

        add(mainPanel);

        setVisible(true);
    }

    private String getFormattedText() {
        return "<html><body style='font-family:Georgia; font-size:16px; color: #333333;'>"
                + "<h1 style='background-color:#add8e6; padding:10px; color: #5a5a5a;'>Welcome to the Cipher Learning Program!</h1>"
                + "<p style='color: darkred;'><b>Encryption:</b> The process of converting information or data into a code, "
                + "especially to prevent unauthorized access.</p>"
                + "<p style='color: darkblue;'><b>Decryption:</b> The process of converting encoded data back into its original form.</p>"
                + "<h2 style='background-color:#ffe4b5; padding:10px; color: #444444;'>Playfair Cipher</h2>"
                + "<p>The Playfair cipher uses a 5x5 matrix of letters based on a keyword. "
                + "Pairs of letters are encoded by their position in the matrix.</p>"
                + "<p style='color: #555555;'><b>Example:</b> Using the keyword 'MONARCHY', the encryption of 'HELLO' could be 'CFFBC'.</p>"
                + "<h2 style='background-color:#ffe4b5; padding:10px; color: #444444;'>Affine Cipher</h2>"
                + "<p>The Affine cipher combines multiplication and addition over a modular base (typically 26 for the English alphabet), "
                + "using two keys, 'a' and 'b'.</p>"
                + "<p style='color: #555555;'><b>Example:</b> Using keys a=5 and b=8, the encryption of 'HELLO' would be 'PLCFF'.</p>"
                + "</body></html>";
    }

    private void styleButton(JButton button) {
        button.setFont(new Font("SansSerif", Font.BOLD, 18));
        button.setBackground(new Color(102, 205, 170));
        button.setForeground(Color.WHITE);
        button.addActionListener(this::openCipherGUI);
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(72, 209, 204)); 
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(new Color(102, 205, 170));
            }
        });
        button.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    }

    private void openCipherGUI(ActionEvent e) {
        this.dispose();
        new CipherGUI();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(IntroGUI::new);
    }
}
