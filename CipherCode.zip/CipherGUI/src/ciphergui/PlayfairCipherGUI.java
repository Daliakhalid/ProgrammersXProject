package ciphergui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class PlayfairCipherGUI extends JFrame {
    private JTextField keyField;
    private JTextField inputText;
    private JTextField outputText;

    public PlayfairCipherGUI() {
        super("Playfair Cipher Encryption/Decryption");
        initializeUI();
    }

    private void initializeUI() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 200);
        setLayout(new FlowLayout());

        add(new JLabel("Key:"));
        keyField = new JTextField(20);
        add(keyField);

        add(new JLabel("Enter Text:"));
        inputText = new JTextField(20);
        add(inputText);

        JButton encryptButton = new JButton("Encrypt");
        encryptButton.addActionListener((ActionEvent e) -> {
            PlayfairCipher cipher = new PlayfairCipher(keyField.getText());
            outputText.setText(cipher.encryptMessage(inputText.getText()));
        });
        add(encryptButton);

        JButton decryptButton = new JButton("Decrypt");
        decryptButton.addActionListener((ActionEvent e) -> {
            PlayfairCipher cipher = new PlayfairCipher(keyField.getText());
            outputText.setText(cipher.decryptMessage(inputText.getText()));
        });
        add(decryptButton);

        add(new JLabel("Result:"));
        outputText = new JTextField(20);
        outputText.setEditable(false);
        add(outputText);

        setVisible(true);
    }

    public static void main(String[] args) {
        new PlayfairCipherGUI();
    }
}
