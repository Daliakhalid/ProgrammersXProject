package ciphergui;

import java.awt.*;
import java.util.LinkedHashSet;
import java.util.Set;

public class PlayfairCipher {

    private char[][] charTable;
    private Point[] positions;

    public PlayfairCipher(String key) {
        this.charTable = generateTable(key);
    }

    private char[][] generateTable(String key) {
        Set<Character> set = new LinkedHashSet<>();
        for (char c : key.toUpperCase().replaceAll("[^A-Z]", "").toCharArray()) {
            if (c != 'J') {
                set.add(c);
            }
        }
        for (char c = 'A'; c <= 'Z'; c++) {
            if (c != 'J') {
                set.add(c);
            }
        }

        char[][] table = new char[5][5];
        int i = 0, j = 0;
        for (Character c : set) {
            table[i][j++] = c;
            if (j == 5) {
                j = 0;
                i++;
            }
        }
        positions = new Point[26];
        for (int k = 0; k < 5; k++) {
            for (int l = 0; l < 5; l++) {
                positions[table[k][l] - 'A'] = new Point(k, l);
            }
        }
        return table;
    }

    public String encryptMessage(String message) {
        return cipherMessage(message, true);
    }

    public String decryptMessage(String message) {
        return cipherMessage(message, false);
    }

    private String prepareText(String text) {
        StringBuilder preparedText = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            char currentChar = text.charAt(i);
            char nextChar = (i + 1 < text.length()) ? text.charAt(i + 1) : 'X';
            preparedText.append(currentChar);
            if (currentChar == nextChar) {
                preparedText.append('X');  
                i++; 
            }
        }
        if (preparedText.length() % 2 != 0) {
            preparedText.append('X');
        }
        return preparedText.toString();
    }

    private String cipherMessage(String message, boolean encrypt) {
        StringBuilder cleanMessage = new StringBuilder();
        StringBuilder builder = new StringBuilder();
        int[] positions = new int[message.length()];
        char[] chars = new char[message.length()];
        int index = 0;

        for (int i = 0; i < message.length(); i++) {
            char ch = message.charAt(i);
            if (Character.isLetter(ch)) {
                cleanMessage.append(ch == 'J' ? 'I' : Character.toUpperCase(ch));
            } else {
                positions[index] = i;
                chars[index++] = ch;
            }
        }

        String preparedText = prepareText(cleanMessage.toString());

            for (int i = 0; i < preparedText.length(); i += 2) {
            char a = preparedText.charAt(i);
            char b = preparedText.charAt(i + 1);
            Point posA = this.positions[a - 'A'];
            Point posB = this.positions[b - 'A'];

            int rowA = posA.x, colA = posA.y;
            int rowB = posB.x, colB = posB.y;

            if (rowA == rowB) { // Same row
                builder.append(charTable[rowA][(colA + (encrypt ? 1 : 4)) % 5]);
                builder.append(charTable[rowB][(colB + (encrypt ? 1 : 4)) % 5]);
            } else if (colA == colB) { // Same column
                builder.append(charTable[(rowA + (encrypt ? 1 : 4)) % 5][colA]);
                builder.append(charTable[(rowB + (encrypt ? 1 : 4)) % 5][colB]);
            } else { // Rectangle swap
                builder.append(charTable[rowA][colB]);
                builder.append(charTable[rowB][colA]);
            }
        }

        for (int i = 0; i < index; i++) {
            builder.insert(positions[i], chars[i]);
        }

        return builder.toString();
    }

}
