//package ciphergui;
//
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//
//public class AffineCipherGUI extends JFrame {
//    private JTextField inputText;
//    private JTextField outputText;
//
//    public AffineCipherGUI() {
//        super("Affine Cipher Encryption/Decryption");
//        initializeUI();
//    }
//
//    private void initializeUI() {
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        setSize(400, 200);
//        setLayout(new FlowLayout());
//
//        add(new JLabel("Enter Text:"));
//        inputText = new JTextField(20);
//        add(inputText);
//
//        JButton encryptButton = new JButton("Encrypt");
//        encryptButton.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                outputText.setText(AffineCipher.encrypt(inputText.getText()));
//            }
//        });
//        add(encryptButton);
//
//        JButton decryptButton = new JButton("Decrypt");
//        decryptButton.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                outputText.setText(AffineCipher.decrypt(inputText.getText()));
//            }
//        });
//        add(decryptButton);
//
//        add(new JLabel("Result:"));
//        outputText = new JTextField(20);
//        outputText.setEditable(false);
//        add(outputText);
//
//        setVisible(true);
//    }
//
//    public static void main(String[] args) {
//        new AffineCipherGUI();
//    }
//}
