package ciphergui;

public class AffineCipher {
    private int a;
    private int b;
    private static final int m = 26;

    public AffineCipher(int a, int b) {
        this.a = a;
        this.b = b;
    }

    private static int modInverse(int a) {
        for (int x = 1; x < m; x++) {
            if ((a * x) % m == 1) {
                return x;
            }
        }
        return 1; 
    }

    public String encrypt(String input) {
        StringBuilder result = new StringBuilder();
        StringBuilder cleanedInput = new StringBuilder();
        int[] positions = new int[input.length()];
        char[] chars = new char[input.length()];
        int index = 0;

        for (int i = 0; i < input.length(); i++) {
            char character = input.charAt(i);
            if (Character.isLetter(character)) {
                cleanedInput.append(Character.toUpperCase(character));
            } else {
                positions[index] = i;
                chars[index] = character;
                index++;
            }
        }

        for (char character : cleanedInput.toString().toCharArray()) {
            int encoded = (a * (character - 'A') + b) % m;
            result.append((char) (encoded + 'A'));
        }

        for (int i = 0; i < index; i++) {
            result.insert(positions[i], chars[i]);
        }

        return result.toString();
    }

    public String decrypt(String input) {
        StringBuilder result = new StringBuilder();
        StringBuilder cleanedInput = new StringBuilder();
        int[] positions = new int[input.length()];
        char[] chars = new char[input.length()];
        int index = 0;

        for (int i = 0; i < input.length(); i++) {
            char character = input.charAt(i);
            if (Character.isLetter(character)) {
                cleanedInput.append(Character.toUpperCase(character));
            } else {
                positions[index] = i;
                chars[index] = character;
                index++;
            }
        }

        int a_inv = modInverse(a);
        for (char character : cleanedInput.toString().toCharArray()) {
            int decoded = a_inv * (character - 'A' - b + m) % m;
            result.append((char) (decoded + 'A'));
        }

        for (int i = 0; i < index; i++) {
            result.insert(positions[i], chars[i]);
        }

        return result.toString();
    }

    public static int gcd(int a, int b) {
        return b == 0 ? a : gcd(b, a % b);
    }
}
