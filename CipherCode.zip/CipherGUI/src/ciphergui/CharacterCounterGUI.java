/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ciphergui;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.HashMap;
import java.util.Map;

public class CharacterCounterGUI extends JFrame {
    private JTextArea inputText = new JTextArea(10, 50); // Allows multiple lines, adjust rows as needed
    private JButton recordButton = new JButton("Record Input");
    private JButton clearButton = new JButton("Clear Input");
    private JButton resetButton = new JButton("Reset Counters");
    private Map<Character, JTextField> counters = new HashMap<>();
    private JTextField totalField = new JTextField(6);

    public CharacterCounterGUI() {
        super("Character Frequency Counter");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        setupNorthPanel();
        setupCenterPanel();
        setupSouthPanel();

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void setupNorthPanel() {
    JPanel northPanel = new JPanel();
    northPanel.setLayout(new BoxLayout(northPanel, BoxLayout.Y_AXIS)); // Change to BoxLayout for vertical stacking

    JLabel inputLabel = new JLabel("Input text:");
    inputLabel.setAlignmentX(Component.LEFT_ALIGNMENT); // Align label to the left
    northPanel.add(inputLabel);

    inputText.setLineWrap(true);
    inputText.setWrapStyleWord(true);
    JScrollPane scrollPane = new JScrollPane(inputText); // Make textarea scrollable
    scrollPane.setAlignmentX(Component.LEFT_ALIGNMENT); // Align scroll pane to the left
    northPanel.add(scrollPane);

    add(northPanel, BorderLayout.NORTH);
}


    private void setupCenterPanel() {
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new GridLayout(0, 9)); // Adjust for the number of columns needed
        String[] labels = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};
        for (String label : labels) {
            JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            panel.add(new JLabel(label));
            JTextField countField = new JTextField("0", 3);
            countField.setHorizontalAlignment(JTextField.RIGHT);
            countField.setEditable(false);
            counters.put(label.charAt(0), countField);
            panel.add(countField);
            centerPanel.add(panel);
        }
        add(centerPanel, BorderLayout.CENTER);
    }

    private void setupSouthPanel() {
        JPanel southPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        recordButton.addActionListener(this::recordInput);
        clearButton.addActionListener(this::clearInput);
        resetButton.addActionListener(this::resetCounters);

        southPanel.add(recordButton);
        southPanel.add(clearButton);
        southPanel.add(resetButton);

        totalField.setEditable(false);
        totalField.setHorizontalAlignment(JTextField.RIGHT);
        southPanel.add(new JLabel("Total:"));
        southPanel.add(totalField);

        add(southPanel, BorderLayout.SOUTH);
    }

    private void recordInput(ActionEvent e) {
        String text = inputText.getText().toUpperCase().replaceAll("\\s+", ""); // Ignores whitespace
        resetCounters(null); // Optional: Clear counts before new input is recorded
        int total = 0;
        for (char c : text.toCharArray()) {
            if (Character.isAlphabetic(c)) { // Only count alphabetic characters
                JTextField field = counters.get(c);
                if (field != null) {
                    int count = Integer.parseInt(field.getText()) + 1;
                    field.setText(String.valueOf(count));
                    total++;
                }
            }
        }
        totalField.setText(String.valueOf(total));
    }

    private void clearInput(ActionEvent e) {
        inputText.setText("");
    }

    private void resetCounters(ActionEvent e) {
        for (JTextField field : counters.values()) {
            field.setText("0");
        }
        totalField.setText("0");
    }

    public static void main(String[] args) {
        new CharacterCounterGUI();
    }
}
